#!/opt/homebrew/Cellar/node/26.7.0/bin/node
import { createHash } from 'node:crypto';
import { constants as fsConstants, promises as fs } from 'node:fs';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { isBuiltin, registerHooks } from 'node:module';
const EXPECTED_SOURCE_DIGEST = "dbd6a40fed1925c802f097d66d82e9a3e9695e5ab63e777bc3de209064b19282";
const EXPECTED_FILES = Object.freeze(["runtime/BEADS.md","runtime/BRIDGE.md","runtime/CODEX_EXEC.md","runtime/WORKFRONT.md","runtime/dist/admission.d.ts","runtime/dist/admission.d.ts.map","runtime/dist/admission.js","runtime/dist/admission.js.map","runtime/dist/authority.d.ts","runtime/dist/authority.d.ts.map","runtime/dist/authority.js","runtime/dist/authority.js.map","runtime/dist/beads.d.ts","runtime/dist/beads.d.ts.map","runtime/dist/beads.js","runtime/dist/beads.js.map","runtime/dist/bridge-cli.d.ts","runtime/dist/bridge-cli.d.ts.map","runtime/dist/bridge-cli.js","runtime/dist/bridge-cli.js.map","runtime/dist/bridge.d.ts","runtime/dist/bridge.d.ts.map","runtime/dist/bridge.js","runtime/dist/bridge.js.map","runtime/dist/canonical.d.ts","runtime/dist/canonical.d.ts.map","runtime/dist/canonical.js","runtime/dist/canonical.js.map","runtime/dist/cli.d.ts","runtime/dist/cli.d.ts.map","runtime/dist/cli.js","runtime/dist/cli.js.map","runtime/dist/codex-effect-records.d.ts","runtime/dist/codex-effect-records.d.ts.map","runtime/dist/codex-effect-records.js","runtime/dist/codex-effect-records.js.map","runtime/dist/codex-exec-driver.d.ts","runtime/dist/codex-exec-driver.d.ts.map","runtime/dist/codex-exec-driver.js","runtime/dist/codex-exec-driver.js.map","runtime/dist/codex-exec-supervisor.d.ts","runtime/dist/codex-exec-supervisor.d.ts.map","runtime/dist/codex-exec-supervisor.js","runtime/dist/codex-exec-supervisor.js.map","runtime/dist/codex-host-policy.d.ts","runtime/dist/codex-host-policy.d.ts.map","runtime/dist/codex-host-policy.js","runtime/dist/codex-host-policy.js.map","runtime/dist/compiler.d.ts","runtime/dist/compiler.d.ts.map","runtime/dist/compiler.js","runtime/dist/compiler.js.map","runtime/dist/composition.d.ts","runtime/dist/composition.d.ts.map","runtime/dist/composition.js","runtime/dist/composition.js.map","runtime/dist/dependency.d.ts","runtime/dist/dependency.d.ts.map","runtime/dist/dependency.js","runtime/dist/dependency.js.map","runtime/dist/driver.d.ts","runtime/dist/driver.d.ts.map","runtime/dist/driver.js","runtime/dist/driver.js.map","runtime/dist/filesystem.d.ts","runtime/dist/filesystem.d.ts.map","runtime/dist/filesystem.js","runtime/dist/filesystem.js.map","runtime/dist/graph.d.ts","runtime/dist/graph.d.ts.map","runtime/dist/graph.js","runtime/dist/graph.js.map","runtime/dist/index.d.ts","runtime/dist/index.d.ts.map","runtime/dist/index.js","runtime/dist/index.js.map","runtime/dist/kernel.d.ts","runtime/dist/kernel.d.ts.map","runtime/dist/kernel.js","runtime/dist/kernel.js.map","runtime/dist/limits.d.ts","runtime/dist/limits.d.ts.map","runtime/dist/limits.js","runtime/dist/limits.js.map","runtime/dist/metrics.d.ts","runtime/dist/metrics.d.ts.map","runtime/dist/metrics.js","runtime/dist/metrics.js.map","runtime/dist/model.d.ts","runtime/dist/model.d.ts.map","runtime/dist/model.js","runtime/dist/model.js.map","runtime/dist/orchestration.d.ts","runtime/dist/orchestration.d.ts.map","runtime/dist/orchestration.js","runtime/dist/orchestration.js.map","runtime/dist/outbox.d.ts","runtime/dist/outbox.d.ts.map","runtime/dist/outbox.js","runtime/dist/outbox.js.map","runtime/dist/public.d.ts","runtime/dist/public.d.ts.map","runtime/dist/public.js","runtime/dist/public.js.map","runtime/dist/reducer.d.ts","runtime/dist/reducer.d.ts.map","runtime/dist/reducer.js","runtime/dist/reducer.js.map","runtime/dist/release-admission.d.ts","runtime/dist/release-admission.d.ts.map","runtime/dist/release-admission.js","runtime/dist/release-admission.js.map","runtime/dist/release-operation.d.ts","runtime/dist/release-operation.d.ts.map","runtime/dist/release-operation.js","runtime/dist/release-operation.js.map","runtime/dist/release-quiescence.d.ts","runtime/dist/release-quiescence.d.ts.map","runtime/dist/release-quiescence.js","runtime/dist/release-quiescence.js.map","runtime/dist/renderer.d.ts","runtime/dist/renderer.d.ts.map","runtime/dist/renderer.js","runtime/dist/renderer.js.map","runtime/dist/reuse.d.ts","runtime/dist/reuse.d.ts.map","runtime/dist/reuse.js","runtime/dist/reuse.js.map","runtime/dist/store.d.ts","runtime/dist/store.d.ts.map","runtime/dist/store.js","runtime/dist/store.js.map","runtime/dist/validator.d.ts","runtime/dist/validator.d.ts.map","runtime/dist/validator.js","runtime/dist/validator.js.map","runtime/dist/workfront.d.ts","runtime/dist/workfront.d.ts.map","runtime/dist/workfront.js","runtime/dist/workfront.js.map","runtime/package.json","runtime/schemas/codex-launch-intent-record.schema.json","runtime/schemas/codex-launch-record.schema.json","runtime/schemas/codex-terminal-record.schema.json","runtime/schemas/codex-worker-result.schema.json","runtime/tools/bind-release-process-snapshot.mjs","runtime/tools/probe-codex-exec.mjs","runtime/tools/verify-release-quiescence.mjs"]);
const EXPECTED_RUNTIME_VERSION = "0.3.0";
const EXPECTED_MANIFEST_DIGEST = "93eca5939a4d69d2b7db78e4947c4a66fb6f591242f37ab8f56a4b33daae2130";
const EXPECTED_LAUNCHER_DIGEST = "6a8ed0f1046ab811d8a33a0d8ec9c9524a7b264e1f3041aecce66a1245978d98";
const EXPECTED_NODE_PATH = "/opt/homebrew/Cellar/node/26.7.0/bin/node";
const EXPECTED_NODE_VERSION = "26.7.0";
const EXPECTED_NODE_DIGEST = "aa7c3390685f1388f3b898b7d7f84edf95fcee4aa062725aa56dee348afbe6be";
const MAX_MANIFEST_BYTES = 1024 * 1024;
const MAX_PAYLOAD_FILE_BYTES = 4 * 1024 * 1024;
const MAX_PAYLOAD_TOTAL_BYTES = 64 * 1024 * 1024;
const runtimeDir = dirname(fileURLToPath(import.meta.url));
const skillRoot = resolve(runtimeDir, "..");
const launcherPath = fileURLToPath(import.meta.url);
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
const verifyNodeRuntime = async () => { const actualPath = resolve(await fs.realpath(process.execPath)); if (actualPath !== EXPECTED_NODE_PATH || process.versions.node !== EXPECTED_NODE_VERSION) throw new Error("Node executable/version is not the attested runtime"); const stat = await fs.stat(actualPath); if (!stat.isFile() || (stat.mode & 0o111) === 0) throw new Error("Node executable is not a regular executable file"); trustedStat(stat, "Node executable"); if (hash(await fs.readFile(actualPath)) !== EXPECTED_NODE_DIGEST) throw new Error("Node executable digest changed"); };
const normalizeLauncher = (bytes) => { let source = bytes.toString("utf8"); for (const [name, marker] of [["MANIFEST", "__LUNACY_MANIFEST_DIGEST__"], ["LAUNCHER", "__LUNACY_LAUNCHER_DIGEST__"]]) { const pattern = new RegExp(`(^const EXPECTED_${name}_DIGEST = ")([0-9a-f]{64})(";)$`, "m"); const normalized = source.replace(pattern, `$1${marker}$3`); if (normalized === source) throw new Error("trusted launcher fingerprint is malformed"); source = normalized; } return Buffer.from(source); };
const trustedStat = (stat, label) => { if (typeof process.getuid === "function" && stat.uid !== process.getuid()) throw new Error(label + " is not owned by the current user"); if ((stat.mode & 0o022) !== 0) throw new Error(label + " is group/world-writable"); };
const pathWithin = (parent, candidate) => candidate === parent || candidate.startsWith(parent + sep);
const tempLexical = resolve(tmpdir());
const tempRoots = [...new Set([tempLexical, "/tmp"])];
const tempPhysical = await Promise.all(tempRoots.map((root) => fs.realpath(root).catch(() => root)));
const allowedTempAlias = async (path) => { for (let index = 0; index < tempRoots.length; index += 1) { if (!pathWithin(path, tempRoots[index])) continue; const actual = await fs.realpath(path).catch(() => ""); if (actual && (pathWithin(actual, tempPhysical[index]) || pathWithin(tempPhysical[index], actual))) return true; } return false; };
const trustedPath = async (path, label, kind = "any", allowMissing = false) => { const target = resolve(path); const parts = target.split(sep).filter(Boolean); let current = sep; let finalStat; let missing = false; for (let index = 0; index < parts.length; index += 1) { current = current === sep ? join(current, parts[index]) : join(current, parts[index]); if (missing) continue; let stat; try { stat = await fs.lstat(current); } catch (error) { if (error.code === "ENOENT") { missing = true; continue; } throw error; } const final = index === parts.length - 1; if (stat.isSymbolicLink()) { if (final || !(await allowedTempAlias(current))) throw new Error(label + " contains an untrusted symlink"); continue; } if ((stat.mode & 0o022) !== 0) { const stickyTemp = (stat.mode & 0o1000) !== 0 && (stat.mode & 0o002) !== 0 && (tempRoots.includes(current) || tempPhysical.includes(current)); if (!stickyTemp) throw new Error(label + " is group/world-writable"); } if (!final && !stat.isDirectory()) throw new Error(label + " ancestor is not a directory"); if (final) finalStat = stat; } if (!finalStat) { if (allowMissing) return undefined; throw new Error(label + " is absent"); } if (kind === "directory" && !finalStat.isDirectory()) throw new Error(label + " is not a directory"); if (kind === "file" && !finalStat.isFile()) throw new Error(label + " is not a regular file"); trustedStat(finalStat, label); return { stat: finalStat, identity: { dev: String(finalStat.dev), ino: String(finalStat.ino) } }; };
const sameIdentity = (a, b) => a.dev === b.dev && a.ino === b.ino;
const stablePath = async (path, expected, label) => { const current = await trustedPath(path, label, "directory"); if (!current || !sameIdentity(current.identity, expected)) throw new Error(label + " changed identity"); };
const safePath = (item) => { if (typeof item !== "string" || !item.startsWith("runtime/") || item.includes(String.fromCharCode(92)) || item.split("/").some((part) => part === "" || part === "." || part === "..")) throw new Error("deployment manifest path is unsafe"); return item; };
const physicalWithin = async (path, label) => { const runtimePhysical = await fs.realpath(runtimeDir); const pathPhysical = await fs.realpath(path); const rel = relative(runtimePhysical, pathPhysical); if (!rel || rel === ".." || rel.startsWith(".." + sep) || pathPhysical !== resolve(runtimePhysical, rel)) throw new Error(label + " escapes the physical runtime directory"); };
const regular = async (path, label, limit = MAX_PAYLOAD_FILE_BYTES) => { if (!Number.isSafeInteger(limit) || limit < 0) throw new Error(label + " has an invalid byte limit"); const runtime = await trustedPath(runtimeDir, "runtime directory", "directory"); const root = await trustedPath(skillRoot, "skill root", "directory"); const before = await trustedPath(path, label, "file"); await physicalWithin(path, label); const handle = await fs.open(path, fsConstants.O_RDONLY | fsConstants.O_NOFOLLOW); try { const stat = await handle.stat(); if (!stat.isFile()) throw new Error(label + " is not a regular file"); trustedStat(stat, label); if (!sameIdentity({ dev: String(stat.dev), ino: String(stat.ino) }, before.identity)) throw new Error(label + " changed before descriptor binding"); const after = await trustedPath(path, label, "file"); if (!after || !sameIdentity({ dev: String(stat.dev), ino: String(stat.ino) }, after.identity)) throw new Error(label + " changed during descriptor binding"); if (!Number.isSafeInteger(stat.size) || stat.size < 0 || stat.size > limit) throw new Error(label + " exceeds its byte limit"); const expected = stat.size; const chunks = []; const buffer = Buffer.allocUnsafe(Math.min(64 * 1024, Math.max(1, expected + 1))); let total = 0; while (true) { const result = await handle.read(buffer, 0, buffer.length, null); if (result.bytesRead === 0) break; if (result.bytesRead > expected - total || result.bytesRead > limit - total) throw new Error(label + " changed during bounded read"); chunks.push(Buffer.from(buffer.subarray(0, result.bytesRead))); total += result.bytesRead; } if (total !== expected) throw new Error(label + " changed during bounded read"); return Buffer.concat(chunks, total); } finally { await handle.close(); } };
const ENTRY_URL = "lunacy:///dist/bridge-cli.js";
const LUNACY_PREFIX = "lunacy:///";
const LAUNCHER_URL = import.meta.url;
let verifiedGraphHookRegistration;
const registerVerifiedGraph = (bytesByPath) => {
  const graph = new Map();
  for (const [item, bytes] of bytesByPath) {
    if (!item.startsWith("runtime/dist/") || !item.endsWith(".js")) continue;
    const modulePath = item.slice("runtime/".length);
    const url = LUNACY_PREFIX + modulePath;
    let parsed;
    try { parsed = new URL(url); } catch { throw new Error("verified module URL is malformed: " + url); }
    if (parsed.href !== url || parsed.protocol !== "lunacy:" || parsed.host !== "" || parsed.username !== "" || parsed.password !== "" || parsed.search !== "" || parsed.hash !== "") throw new Error("verified module URL is non-canonical: " + url);
    const source = bytes.toString("utf8");
    if (!Buffer.from(source, "utf8").equals(bytes)) throw new Error("verified module source is not UTF-8: " + url);
    if (graph.has(url)) throw new Error("verified module URL is duplicated: " + url);
    graph.set(url, Object.freeze({ bytes, source }));
  }
  const graphHas = Map.prototype.has.bind(graph);
  const graphGet = Map.prototype.get.bind(graph);
  if (!graphHas(ENTRY_URL)) throw new Error("verified module entry is absent: " + ENTRY_URL);
  const isLunacyURL = (value) => { if (typeof value !== "string") return false; try { return new URL(value).protocol === "lunacy:"; } catch { return false; } };
  verifiedGraphHookRegistration = registerHooks({
    resolve(specifier, context, nextResolve) {
      const parentURL = context.parentURL;
      if (specifier === ENTRY_URL && parentURL === LAUNCHER_URL) return { url: ENTRY_URL, shortCircuit: true };
      if (typeof parentURL === "string" && graphHas(parentURL)) {
        if (specifier.startsWith("./") || specifier.startsWith("../")) {
          if (specifier.includes("%")) throw new Error("verified module is absent: " + specifier);
          let resolved;
          try { resolved = new URL(specifier, parentURL); } catch { throw new Error("verified module is absent: " + specifier); }
          const url = resolved.href;
          if (resolved.protocol !== "lunacy:" || resolved.host !== "" || resolved.username !== "" || resolved.password !== "" || resolved.search !== "" || resolved.hash !== "" || !graphHas(url)) throw new Error("verified module is absent: " + url);
          return { url, shortCircuit: true };
        }
        if (!isBuiltin(specifier)) throw new Error("unverified module specifier: " + specifier);
        const resolved = nextResolve(specifier, context);
        if (!resolved || typeof resolved.url !== "string" || !resolved.url.startsWith("node:") || !isBuiltin(resolved.url)) throw new Error("unverified module specifier: " + specifier);
        return resolved;
      }
      if (isLunacyURL(specifier) || isLunacyURL(parentURL)) throw new Error("unverified module specifier: " + specifier);
      const resolved = nextResolve(specifier, context);
      if (isLunacyURL(resolved?.url)) throw new Error("unverified module specifier: " + specifier);
      return resolved;
    },
    load(url, context, nextLoad) {
      const record = graphGet(url);
      if (record !== undefined) return { format: "module", source: record.source, shortCircuit: true };
      if (isLunacyURL(url)) throw new Error("verified module is absent: " + url);
      return nextLoad(url, context);
    },
  });
  return import(ENTRY_URL).then((module) => module.runBridgeCli());
};
async function verifyDeployment() {
  const launcherStat = await fs.lstat(launcherPath); if (launcherStat.isSymbolicLink()) throw new Error("trusted launcher is a symlink"); trustedStat(launcherStat, "trusted launcher");
  const launcherBytes = await regular(launcherPath, "trusted launcher");
  if (hash(normalizeLauncher(launcherBytes)) !== EXPECTED_LAUNCHER_DIGEST) throw new Error("deployment fingerprint is not the trusted release");
  const skill = await trustedPath(skillRoot, "skill root", "directory"); const runtime = await trustedPath(runtimeDir, "runtime directory", "directory"); const skillIdentity = skill.identity; const runtimeIdentity = runtime.identity;
  await stablePath(skillRoot, skillIdentity, "skill root"); await stablePath(runtimeDir, runtimeIdentity, "runtime directory");
  const manifestPath = join(runtimeDir, "DEPLOYMENT.json");
  const manifestBytes = await regular(manifestPath, "deployment manifest", MAX_MANIFEST_BYTES);
  const manifest = JSON.parse(manifestBytes.toString("utf8"));
  if (!manifest || Object.keys(manifest).sort().join(",") !== "bridgeVersion,files,launcherDigest,runtimeVersion,schema,sourceDigest" || manifest.schema !== 1 || manifest.bridgeVersion !== "0.2.0" || manifest.runtimeVersion !== EXPECTED_RUNTIME_VERSION || typeof manifest.sourceDigest !== "string" || !/^[0-9a-f]{64}$/.test(manifest.sourceDigest) || typeof manifest.launcherDigest !== "string" || !/^[0-9a-f]{64}$/.test(manifest.launcherDigest) || !Array.isArray(manifest.files) || manifest.files.length === 0) throw new Error("deployment manifest is malformed or runtime version is not trusted");
  if (hash(manifestBytes) !== EXPECTED_MANIFEST_DIGEST || manifest.launcherDigest !== EXPECTED_LAUNCHER_DIGEST) throw new Error("deployment fingerprint is not the trusted release");
  const files = manifest.files.map(safePath);
  if (files.length !== EXPECTED_FILES.length || files.some((item, index) => item !== EXPECTED_FILES[index]) || new Set(files).size !== files.length) throw new Error("deployment manifest release file list is not trusted");
  const records = []; const bytesByPath = new Map(); let payloadBytes = 0;
  for (const item of files) { await stablePath(skillRoot, skillIdentity, "skill root"); await stablePath(runtimeDir, runtimeIdentity, "runtime directory"); const path = resolve(skillRoot, item); const rel = relative(skillRoot, path); if (!rel || rel === ".." || rel.startsWith(".." + sep) || path !== resolve(skillRoot, rel)) throw new Error("deployment manifest path escapes skill root"); const remaining = MAX_PAYLOAD_TOTAL_BYTES - payloadBytes; const bytes = await regular(path, item, Math.min(MAX_PAYLOAD_FILE_BYTES, remaining)); payloadBytes += bytes.byteLength; if (payloadBytes > MAX_PAYLOAD_TOTAL_BYTES) throw new Error("deployment payload exceeds aggregate byte limit"); bytesByPath.set(item, bytes); records.push({ path: item, digest: hash(bytes) }); }
  const sourceDigest = hash(Buffer.from(records.map((record) => record.path + String.fromCharCode(0) + record.digest).join(String.fromCharCode(10))));
  if (sourceDigest !== EXPECTED_SOURCE_DIGEST || sourceDigest !== manifest.sourceDigest) throw new Error("deployment fingerprint is not the trusted release");
  return { bytesByPath };
}
verifyNodeRuntime().then(() => verifyDeployment().then(({ bytesByPath }) => registerVerifiedGraph(bytesByPath))).then((code) => { process.exitCode = code; }).catch((error) => { process.stderr.write(JSON.stringify({ error: String(error?.message ?? error) }) + "\n"); process.exitCode = 1; });
