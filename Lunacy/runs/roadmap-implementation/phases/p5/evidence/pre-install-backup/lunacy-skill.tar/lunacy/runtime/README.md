# Lunacy runtime bridge (deployed)

This directory is generated from the canonical Desktop Lunacy runtime source.
Use "$NODE" runtime/bridge.mjs --help for one-event transitions.
Use "$NODE" runtime/bridge.mjs drive --help for the private event-driven Codex
drive route.  The managed runtime also carries the exact closed Codex result,
launch-intent, launch, and terminal schemas plus the capability probe under runtime/schemas/
and runtime/tools/; all are covered by DEPLOYMENT.json.
Use "$NODE" runtime/bridge.mjs workfront --help for a read-only dependency capsule.
The optional read-only Beads v1.2.2 adapter is documented in runtime/BEADS.md
and requires an operator-provisioned absolute bd path; it never installs or
searches PATH.
No package manager, network install, provider, worker scheduler, or global PATH
mutation is performed by deployment. The parent must choose --mode runtime
or --mode markdown explicitly for each run.
